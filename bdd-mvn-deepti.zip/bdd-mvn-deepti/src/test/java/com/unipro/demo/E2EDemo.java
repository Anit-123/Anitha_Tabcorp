package com.unipro.demo;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class E2EDemo {

	public static void main(String[] args) throws InterruptedException {
		Actions ac;
		System.setProperty("webdriver.chrome.driver", "./tools/chromedriver/win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://103.231.211.145/Testing/");
		driver.findElement(By.id("txtUserName")).sendKeys("aa");
		driver.findElement(By.id("txtPassword")).sendKeys("ups@123");
		driver.findElement(By.id("btnSignIn")).click();
		String title = driver.getTitle();
		System.out.println("Print the title: " + title);
		// driver.quit();
		String inventoryurl = "http://103.231.211.145/Testing/Inventory/frmInventoryMaster.aspx";
		driver.navigate().to(inventoryurl);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='menuUserControl_menu']/li[2]/a")).click();
		// Actions ac = new Actions(driver);
		WebElement addInventory = driver.findElement(By.xpath("//*[@id='menuUserControl_menu']/li[2]/ul/li[1]/a"));
		Thread.sleep(5000);
		addInventory.click();
		// ac.moveToElement(addInventory).build().perform();

		// invoking the popup of category selection
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtInvcategory']")).sendKeys("P");
		// clear and enter value in search box

		WebElement inputSearcBox = driver.findElement(By.xpath("//input[@id='txtSearch']"));

		inputSearcBox.clear();

		inputSearcBox.sendKeys("Plastic ");

		Thread.sleep(2000);
		inputSearcBox.sendKeys("bowls ");
		Thread.sleep(2000);
		inputSearcBox.sendKeys(" ");

		// clicking on selected value from table

		driver.findElement(By.xpath("//*[@id='table-Search']/tbody/tr/td[1]")).click();

		// invoking the popup of ItemName
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtItemName']")).sendKeys("A");

		// invoking popup of itemtype
		List<WebElement> ddItemNames = driver.findElements(By.cssSelector("li.ui-menu-item"));

		for(WebElement webElement : ddItemNames) {
			if (webElement.getText().contains("855953 - A S E STEAM VAPORIZER")) {
				webElement.click();
			}
		}

		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtItemType']")).sendKeys("b");
		WebElement searchbox = driver.findElement(By.xpath("//*[@id='txtSearch']"));
		searchbox.clear();
		searchbox.sendKeys("b");
		Thread.sleep(2000);
		// selecting itemtype from table in popup
		driver.findElement(By.xpath("//*[@id='table-Search']/tbody/tr/td[1]")).click();

		// selecting Activationsetting button
		driver.findElement(By.xpath("//*[@id='liActivationSettings']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_chkShelf']")).click();
		// selecting Order&breakprice button
		driver.findElement(By.xpath("//*[@id='liBreakPrice']/a"));
		Select bydropdown = new Select(driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_ddlMiniBy']")));
		bydropdown.selectByVisibleText("Manual");
		// selecting inventorypricing button and radiobutton
		driver.findElement(By.xpath("//*[@id='liInventoryPricing']/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_rbnMRP2']")).click();
		// Clicking arrow
		driver.findElement(By.id("ContentPlaceHolder1_imgPriceChange")).click();
		// invoking the IGST dropdown
		driver.findElement(By.cssSelector("#ContentPlaceHolder1_ddlInputIGST_chzn > a > span")).click();
		WebElement ddsearch = driver.findElement(By.cssSelector("#ContentPlaceHolder1_ddlInputIGST_chzn > div > div > input[type=text]"));
		ddsearch.sendKeys("12");
		Thread.sleep(2000);
		ddsearch.sendKeys(Keys.ARROW_DOWN);
		ddsearch.sendKeys(Keys.ENTER);
		// input Cess%
		WebElement cess = driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtCESSPrc']"));
		cess.clear();
		cess.sendKeys("1");
		// input Mrp/Dis%/AdlDis%
		WebElement mrp = driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtMRP']"));
		mrp.clear();
		mrp.sendKeys("100");
		WebElement dis = driver.findElement(By.cssSelector("input#ContentPlaceHolder1_txtMRPMarkDown.form-control-res.text-right"));
		dis.clear();
		dis.sendKeys("2");
		WebElement adldis = driver.findElement(By.cssSelector("input#ContentPlaceHolder1_txtAdDiscount.form-control-res.text-right"));
		adldis.clear();
		adldis.sendKeys("1");
		
	/*//	while (ddsearch != null) {
			if(ddsearch..sendKeys() is ){
				*/
			//}
			
	//	}
		
		
		
		
		
		
		
		
		
		
	}

}
