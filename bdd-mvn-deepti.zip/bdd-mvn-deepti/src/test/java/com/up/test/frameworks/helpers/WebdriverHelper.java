package com.up.test.frameworks.helpers;

import java.util.logging.Level;

import org.apache.poi.hssf.record.formula.functions.If;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebdriverHelper extends EventFiringWebDriver {

	
	private static final Logger LOG = LoggerFactory.getLogger(WebdriverHelper.class);
	private static RemoteWebDriver REAL_DRIVER;

	private static final Thread CLOSE_THREAD = new Thread() {

		@Override
		public void run() {

			REAL_DRIVER.quit();
		}

	};
	
	private WebdriverHelper() {
		super(REAL_DRIVER);
		// TODO Auto-generated constructor stub
	}


	private static String BROWSER;
	private static String PLATFORM;
	private static String DRIVER_PATH;
	private static String DRIVER_ROOT_DIR;
	private static String SELENIUM_HOST;
	private static String SELENIUM_PORT;
	private static String SELENIUM_REMOTE_URL;

	private static Dimension BROWSER_WINDOW_SIZE;
	private static Integer BROWSER_WINDOW_WIDTH;
	private static Integer BROWSER_WINDOW_HEIGHT;

	static {

		Props.loadRunConfigProps("/environment.properties");
		SELENIUM_HOST = Props.getProp("driverhost");
		SELENIUM_PORT = Props.getProp("driverhost");
		PLATFORM = Props.getProp("platform");
		BROWSER = Props.getProp("platform");
		BROWSER_WINDOW_WIDTH = Integer.parseInt(Props.getProp("width"));
		BROWSER_WINDOW_HEIGHT = Integer.parseInt(Props.getProp("height"));
		BROWSER_WINDOW_SIZE = new Dimension(BROWSER_WINDOW_WIDTH, BROWSER_WINDOW_HEIGHT);
		DRIVER_ROOT_DIR = Props.getProp("driver.root.dir");

		if (!DRIVER_ROOT_DIR.equals("DEFAULT_PATH")) {

			System.setProperty("webdriver.chrome.driver", getDriverPath());
			System.setProperty("webdriver.ie.driver", getDriverPath());
			System.setProperty("webdriver.gecko.driver", getDriverPath());

		}

		switch (BROWSER.toLowerCase()) {
		case ("chrome"):
			startChromeDriver();

			break;

		default:
			throw new IllegalArgumentException("");
		}
	}

	private static String getDriverPath() {
		DRIVER_PATH = Props.getProp("driver.root.dir");
		return DRIVER_PATH;

	}

	private static WebDriver startChromeDriver() {

		DesiredCapabilities capabilities = getChromeCapabilities();

		if (SELENIUM_HOST == null || SELENIUM_HOST.isEmpty()) {

			REAL_DRIVER = new ChromeDriver(ChromeDriverService.createDefaultService(), capabilities);

		} else {

		}
		REAL_DRIVER.manage().window().setSize(BROWSER_WINDOW_SIZE);
		return REAL_DRIVER;

	}

	private static DesiredCapabilities getChromeCapabilities() {

		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.DRIVER, Level.OFF);

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();

		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-extensions");
		chromeOptions.addArguments("--disable-web-securitys");
		chromeOptions.addArguments("--test-type");
		chromeOptions.setCapability("chrome.verbose", false);

		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logs);
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		return capabilities;
	}
	
	public static WebDriver getWebDriver() {
		return REAL_DRIVER;
		
	}

}
