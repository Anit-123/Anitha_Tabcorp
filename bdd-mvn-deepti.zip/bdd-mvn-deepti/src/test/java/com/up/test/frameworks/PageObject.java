package com.up.test.frameworks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.up.test.frameworks.helpers.WebdriverHelper;

import lombok.Getter;

public abstract class PageObject {

	private static final Logger LOG = LoggerFactory.getLogger(PageObject.class);
	private static final long DRIVER_WAIT_TIME = 30;

	@Getter
	protected WebDriverWait wait;

	@Getter
	protected WebDriver webdriver;

	protected PageObject() {

		this.webdriver = WebdriverHelper.getWebDriver();

		this.wait = new WebDriverWait(webdriver, DRIVER_WAIT_TIME);
	}

	protected void maximize_Browser_Winidow() {

		webdriver.manage().window().maximize();
	}

	/**
	 * Returns the current url from page
	 */

	protected String getCurrentUrl() {

		return webdriver.getCurrentUrl();

	}

	/**
	 * Returns the current Title of the page
	 */

	protected String getCurrentTitle() {

		return webdriver.getTitle();

	}

	/**
	 * Returns the current Title of the page
	 * 
	 * @param title the title expected which must be an exact match
	 * @return true when the title matches ,false otherwise
	 */

	protected boolean checkPageTitle(String title) {

		return new WebDriverWait(WebdriverHelper.getWebDriver(), DRIVER_WAIT_TIME)
				.until(ExpectedConditions.titleIs(title));

	}

	/**
	 * Returns the current Title of the page
	 * 
	 * @param title the title expected which must have partial match
	 * @return true when the title matches ,false otherwise
	 */

	protected boolean checkPageTitleContains(String title) {

		return new WebDriverWait(WebdriverHelper.getWebDriver(), DRIVER_WAIT_TIME)
				.until(ExpectedConditions.titleContains(title));

	}

	/**
	 * R
	 * 
	 * @param url the title expected which must have partial match
	 * @return true when the title matches ,false otherwise
	 */

	protected boolean checkPageUrlToBe(String url) {

		return new WebDriverWait(WebdriverHelper.getWebDriver(), DRIVER_WAIT_TIME)
				.until(ExpectedConditions.urlToBe(url));

	}

	/**
	 * R
	 * 
	 * @param url the title expected which must have partial match
	 * @return true when the title matches ,false otherwise
	 */

	public boolean checkPageUrlContains(String url) {

		return new WebDriverWait(WebdriverHelper.getWebDriver(), DRIVER_WAIT_TIME)
				.until(ExpectedConditions.urlContains(url));

	}

	
	public WebElement waitForExpectedElement(final WebElement webElement) {
		return wait.until(ExpectedConditions.visibilityOf(webElement));

	}

}
