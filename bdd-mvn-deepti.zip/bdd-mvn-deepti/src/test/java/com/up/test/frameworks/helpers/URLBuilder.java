package com.up.test.frameworks.helpers;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class URLBuilder {
	
	static WebDriver driver;
	

	private static final Logger LOG = LoggerFactory.getLogger(URLBuilder.class);
	private static final String RUN_CONFIG_PROPERTIES = "/environment.properties";
	private static URL basepath;

	static {

		try {
			Props.loadRunConfigProps(RUN_CONFIG_PROPERTIES);
			basepath = new URL(Props.getProp("unipro.site.url"));

		} catch (MalformedURLException e) {
			// TODO: handle exception

			LOG.error(e.getMessage());
		}

	}
	
	public static void startHomePage() {
		
		driver.navigate().to(basepath);
		
	}

	

}
