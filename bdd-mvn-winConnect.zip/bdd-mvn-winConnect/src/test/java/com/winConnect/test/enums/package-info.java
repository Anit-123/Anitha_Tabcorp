/**
 * 
 */
/**
 * @author jarvis
 *
 */
package com.winConnect.test.enums;