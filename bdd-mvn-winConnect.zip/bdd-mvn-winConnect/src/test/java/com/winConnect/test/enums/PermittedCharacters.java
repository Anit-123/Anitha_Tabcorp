package com.winConnect.test.enums;

public enum PermittedCharacters {
    ANY_CHARACTERS_SUPPORTS_MULTILINGUAL,
    ANY_CHARACTERS,
    ALPHANUMERIC,
    ALPHABETS,
    NUMERIC
}
